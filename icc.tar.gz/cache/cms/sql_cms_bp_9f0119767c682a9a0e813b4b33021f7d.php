<?php exit; ?>
1450277180
SELECT * FROM cms_block_position WHERE layout = 1
601
a:6:{i:0;a:4:{s:4:"bpid";s:2:"13";s:6:"layout";s:1:"1";s:4:"pkey";s:4:"left";s:9:"bposition";s:1:"l";}i:1;a:4:{s:4:"bpid";s:2:"14";s:6:"layout";s:1:"1";s:4:"pkey";s:6:"center";s:9:"bposition";s:1:"c";}i:2;a:4:{s:4:"bpid";s:2:"15";s:6:"layout";s:1:"1";s:4:"pkey";s:5:"right";s:9:"bposition";s:1:"r";}i:3;a:4:{s:4:"bpid";s:2:"16";s:6:"layout";s:1:"1";s:4:"pkey";s:6:"xsnews";s:9:"bposition";s:1:"x";}i:4;a:4:{s:4:"bpid";s:2:"17";s:6:"layout";s:1:"1";s:4:"pkey";s:3:"nav";s:9:"bposition";s:1:"n";}i:5;a:4:{s:4:"bpid";s:2:"18";s:6:"layout";s:1:"1";s:4:"pkey";s:12:"centerbottom";s:9:"bposition";s:1:"b";}}