<?php

// eXtreme Styles mod cache. Generated on Tue, 16 Dec 2014 14:00:41 +0000 (time = 1418738441)

if (!defined('IN_INFINITYCORECMS')) exit;

?><table class="empty-table" width="100%" cellspacing="0" cellpadding="0" border="0">
<tr>
	<td>
		<span class="gensmall"><?php echo isset($this->vars['B_TOTAL_USERS_ONLINE']) ? $this->vars['B_TOTAL_USERS_ONLINE'] : $this->lang('B_TOTAL_USERS_ONLINE'); ?><br /><br /></span>
		<span class="gensmall"><?php echo isset($this->vars['B_LOGGED_IN_USER_LIST']) ? $this->vars['B_LOGGED_IN_USER_LIST'] : $this->lang('B_LOGGED_IN_USER_LIST'); ?><br /><br /></span>
		<div style="text-align:center;"><span class="gensmall">[ <a href="<?php echo isset($this->vars['B_U_VIEWONLINE']) ? $this->vars['B_U_VIEWONLINE'] : $this->lang('B_U_VIEWONLINE'); ?>"><?php echo isset($this->vars['B_L_VIEW']) ? $this->vars['B_L_VIEW'] : $this->lang('B_L_VIEW'); ?></a> ]</span></div><br />
		<span class="gensmall"><?php echo isset($this->vars['B_RECORD_USERS']) ? $this->vars['B_RECORD_USERS'] : $this->lang('B_RECORD_USERS'); ?></span>
	</td>
</tr>
</table>