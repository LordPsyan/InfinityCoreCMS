<?php exit; ?>
1450274441
354
a:12:{i:0;s:13:"settings_site";i:1;s:13:"settings_cron";i:2;s:17:"settings_calendar";i:3;s:17:"settings_security";i:4;s:16:"settings_various";i:5;s:14:"settings_users";i:6;s:20:"settings_img_posting";i:7;s:16:"settings_posting";i:8;s:19:"settings_sql_charge";i:9;s:29:"settings_categories_hierarchy";i:10;s:12:"settings_seo";i:11;s:15:"settings_server";}