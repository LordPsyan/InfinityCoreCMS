<?php exit; ?>
1450272949
SELECT * FROM autolinks WHERE link_forum = 0 OR link_forum IN (999999)
6
a:0:{}