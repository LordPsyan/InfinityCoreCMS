<?php

// eXtreme Styles mod cache. Generated on Tue, 16 Dec 2014 14:00:41 +0000 (time = 1418738441)

if (!defined('IN_INFINITYCORECMS')) exit;

?><table class="empty-table" width="100%" cellspacing="0" cellpadding="0" border="0">
<tr><td><span class="gensmall"><?php echo isset($this->vars['TOTAL_USERS']) ? $this->vars['TOTAL_USERS'] : $this->lang('TOTAL_USERS'); ?><br /><?php echo isset($this->vars['NEWEST_USER']) ? $this->vars['NEWEST_USER'] : $this->lang('NEWEST_USER'); ?><br /><br /><?php echo isset($this->vars['TOTAL_POSTS']) ? $this->vars['TOTAL_POSTS'] : $this->lang('TOTAL_POSTS'); ?> <?php echo isset($this->vars['TOTAL_TOPICS']) ? $this->vars['TOTAL_TOPICS'] : $this->lang('TOTAL_TOPICS'); ?></span></td></tr>
</table>