<?php
/**
*
* @package InfinityCoreCMS
* @version $Id$
* @copyright (c) 2014 InfinityCoreCMS
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_INFINITYCORECMS'))
{
	die('Hacking attempt');
}

/*
* The base path for this array is always the smileys path set in ACP.
* If you want to add a different prefix path, you can add it to the files_list array:
* $files_list = array(
* 'cats/nice/icon_mrblue.gif',
* );
*
*/


$cat_name = 'Demo';
$smileys_list = array(
'icon_mrblue.gif',
'icon_mrgreen.gif',
'icon_mricy.gif',
'icon_mrorange.gif',
'icon_mrviolet.gif',
'icon_mryellow.gif',
'icy_lol_flag.gif',
'icon_evil.gif',
'icon_twisted.gif',
);

?>