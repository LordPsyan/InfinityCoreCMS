<?php exit; ?>
1450272949
SELECT * FROM acronyms
6
a:0:{}