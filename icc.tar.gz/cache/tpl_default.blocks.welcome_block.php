<?php

// eXtreme Styles mod cache. Generated on Tue, 16 Dec 2014 14:00:41 +0000 (time = 1418738441)

if (!defined('IN_INFINITYCORECMS')) exit;

?><table class="empty-table" width="100%" cellspacing="0" cellpadding="0" border="0">
<tr>
	<td width="5%"><img src="images/icy_phoenix_small.png" alt="" /></td>
	<td width="90%" align="center"><?php echo isset($this->vars['L_WELCOME_MESSAGE']) ? $this->vars['L_WELCOME_MESSAGE'] : $this->lang('L_WELCOME_MESSAGE'); ?><br /><br /></td>
	<td width="5%"><img src="images/icy_phoenix_small_l.png" alt="" /></td>
</tr>
</table>