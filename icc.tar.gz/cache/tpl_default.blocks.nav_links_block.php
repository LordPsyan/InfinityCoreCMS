<?php

// eXtreme Styles mod cache. Generated on Tue, 16 Dec 2014 14:00:41 +0000 (time = 1418738441)

if (!defined('IN_INFINITYCORECMS')) exit;

?><?php  $this->set_filename('xs_include_66f1f7a785a53f722d7281592bc4205e', 'nav_quick_links.tpl', true);  $this->pparse('xs_include_66f1f7a785a53f722d7281592bc4205e');  ?>
