<?php exit; ?>
1450277180
SELECT * FROM cms_layout WHERE lid = '1'
265
a:1:{i:0;a:10:{s:3:"lid";s:1:"1";s:4:"name";s:9:"3 Columns";s:8:"filename";s:0:"";s:8:"template";s:12:"3_column.tpl";s:13:"layout_cms_id";s:1:"0";s:13:"global_blocks";s:1:"0";s:8:"page_nav";s:1:"1";s:11:"config_vars";s:0:"";s:4:"view";s:1:"0";s:6:"groups";s:0:"";}}